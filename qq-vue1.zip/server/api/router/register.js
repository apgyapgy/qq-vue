import express from 'express';

const registerRouter = express.Router();

export default registerRouter;