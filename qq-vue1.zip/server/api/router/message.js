import express from 'express';

const messageRouter = express.Router();

export default messageRouter;