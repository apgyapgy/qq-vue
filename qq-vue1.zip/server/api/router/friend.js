import express from 'express';

const friendRouter = express.Router();

export default friendRouter;