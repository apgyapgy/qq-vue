<template>
	<!-- 消息 -->
	<div class="wrapper">
		<VAsideMenu></VAsideMenu>
	</div>
</template>
<script>
	import VAsideMenu from '@/components/Common/SideMenu/SideMenu';
	export default{
		components:{VAsideMenu}
	}
</script>
<style scoped lang="less"></style>