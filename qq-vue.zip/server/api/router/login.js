import express from 'express';

const loginRouter = express.Router();

export default loginRouter;