import express from 'express';

const userRouter = express.Router();

export default userRouter;