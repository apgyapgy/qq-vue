import express from 'express';

const chatGroupRouter = express.Router();

export default chatGroupRouter;