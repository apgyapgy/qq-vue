import express from 'express';

const chatRouter = express.Router();

export default chatRouter;